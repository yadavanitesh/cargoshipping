// Header Scroll
let nav = document.querySelector(".navbar");
window.onscroll = function(){
    if(document.documentElement.scrollTop > 50){
        nav.classList.add("header-scrolled");
    }else{
        nav.classList.remove("header-scrolled");
    }
}

// nav hide
let navBar = document.querySelectorAll(".nav-link");
let navCollapse = document.querySelector(".navbar-collapse.collapse");
navBar.forEach(function(e){
    e.addEventListener("click",function(){
        navCollapse.classList.remove("");

    })
})

//contact us....

const form = document.querySelector('form');
const fullName = document.getElementById("name");
const email = document.getElementById("email");
const phone = document.getElementById("phone");
const subject = document.getElementById("subject");
const mess = document.getElementById("message");

function sendEmail(){
    const bodyMessage = `Full Name: ${fullName.value}<br> Email: ${email.value}<br> phone Number: ${phone.value}<br> Message: ${MediaSession.value}`;


    Email.send({
    Host : "smtp.gmail.com",
    Username : "aaasinfotech01@gmail.com",
    Password : "5FE28A895FCA0A3C24CEFA72FC30EE6827F2",
    post:587,
    To : 'aaasinfotech01@gmail.com',
    From : "aaasinfotech01@gmail.com",
    Subject : subject.value,
    Body : "bodyMessage"
}).then(
  message => {
    if (message == "OK") {
        Swal.fire({
            title: "Success!",
            text: "Message sent Successfully!",
            icon: "success"
        });
    }
  }
);

form.addEventListener("submit", (e) => {
    e.preventDefault();

    sendEmail();
});
}


// counter start js design.
document.addEventListener("DOMContentLoaded", () => {
    function counter(id, start, end, duration){
        let obj = document.getElementById(id),
        current = start, 
        range = end - start,
        increment = end > start ? 1 : -1,
        step = Math.abs(Math.floor(duration / range)),
        timer = setInterval(()=>{
            current += increment
            obj.textContent = current;
            if(current == end){
                clearInterval(timer);
            }
        }, step);
    }

    counter("count1",  0, 1287, 3000);
    counter("count2",  100, 5786, 2500);
    counter("count3",  0, 1440, 3000);
    counter("count4",  0, 2210, 3000);
});